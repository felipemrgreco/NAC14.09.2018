package com.example.logonrmlocal.nac;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void doSearch(View view){

        EditText edtId = findViewById(R.id.edtId);

       String url = "https://jsonplaceholder.typicode.com/todos/";
        url += edtId.getText().toString();

        TextView txtTitle = findViewById(R.id.txtTitle);
        TextView txtCompleted = findViewById(R.id.txtCompleted);

        new DataGetter(txtTitle,txtCompleted).execute(url);

               edtId.selectAll();
    }


}
