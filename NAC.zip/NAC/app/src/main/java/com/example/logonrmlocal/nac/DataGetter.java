package com.example.logonrmlocal.nac;

import android.os.AsyncTask;
import android.widget.TextView;
import org.json.JSONObject;
import org.json.JSONException;


public class DataGetter extends AsyncTask<String,Void,String> {

    private TextView txtCompleted;
    private TextView txtTitle;


    public DataGetter(TextView txtTitle, TextView txtCompleted) {
        this.txtCompleted = txtCompleted;
        this.txtTitle = txtTitle;

    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected String doInBackground(String... strings) {

        String url = strings[0];
        String result = NetworkToolkit.doGet(url);

        return result;
    }

    @Override
    protected void onPostExecute(String s) {

        try
        {
            JSONObject jsonObject = new JSONObject(s);
            String title = jsonObject.getString("title");
            boolean completed = jsonObject.getBoolean("completed");


            txtTitle.setText(title);
            txtCompleted.setText(String.valueOf(completed));

        }
        catch(JSONException e){

            this.txtTitle.setText(e.toString());
        }
    }
}






